
# Fraud Detection Dataset Documentation
## Sources
1. **Ethereum Blockchain Data**
   - Source: Google BigQuery Public Crypto Dataset
   - Period: Last 90 days
   - Records: 50000
   - Fraud Label: Based on Ethereum blacklist addresses

2. **Credit Card Transactions**
   - Source: Kaggle Credit Card Fraud Detection
   - Records: 284807
   - Original Features: Anonymized PCA components
   - Added Metadata: Synthetic merchant/country data

3. **Fraud Patterns**
   - Modeled after PayPal's public fraud reports
   - Includes: Geo patterns, velocity checks, high-risk flags

## Dataset Summary
- Total records: 334807
- Fraud rate: 5.53%
- Columns: ['txn_id', 'user_id', 'timestamp', 'amount', 'currency', 'is_fraud', 'risk_score', 'source', 'country', 'merchant', 'latitude', 'longitude']

⚠️ **Ethical Note**: No real user identities or sensitive financial details are included.
